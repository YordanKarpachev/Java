package ObjecktAndClassesExercise.Artikles_02;

public class Article {
    private String title;
    private String content;
    private String author;

    //konstruktor -> suzdavane na obekt (instanciq) ot tozi klas
    public Article(String title, String content, String author) {
        this.title = title;
        this.content = content;
        this.author = author;
    }


    public String getTitle() {
        return this.title;
    }
    public void setTitle(String newTitle) {
        this.title = newTitle;
    }
    public String getContent(){
        return content;
    }

    public void setContent(String newContent) {
        this.content = newContent;
    }
    public void setAuthor (String newAuthor){
        this.author = newAuthor;
    }
    public String getAuthor(){
        return this.author;

    }

    @Override
    public String toString() {
        return this.title + " - " + this.content + ": " + this.author;
    }
}

