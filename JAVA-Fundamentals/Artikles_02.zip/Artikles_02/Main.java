package ObjecktAndClassesExercise.Artikles_02;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String[] artikelParts = scanner.nextLine().split(", ");

        String title = artikelParts[0];
        String content = artikelParts[1];
        String author = artikelParts[2];

        Article article = new Article(title, content,author);


        int commandsCount = Integer.parseInt(scanner.nextLine());

        for (int icpunt = 1; icpunt <= commandsCount; icpunt++) {

            String command = scanner.nextLine();
            String commandName = command.split(": ")[0];
            String newValue = command.split(": ")[1];

            switch (commandName) {
                case  "Edit":
                    article.setContent(newValue);
                    break;
                case "ChangeAuthor":
                    article.setAuthor(newValue);
                    break;
                case "Rename":
                    article.setTitle(newValue);
                    break;
            }

        }
        System.out.println(article);
    }

    }

