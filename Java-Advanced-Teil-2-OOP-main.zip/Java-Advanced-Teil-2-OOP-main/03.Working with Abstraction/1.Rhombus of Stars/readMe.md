Create a program that reads a positive integer n as input and prints on the console a rhombus with size n:

