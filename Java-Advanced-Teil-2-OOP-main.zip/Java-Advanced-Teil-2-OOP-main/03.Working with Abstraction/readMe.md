Working with Abstraction: Lab
This document defines the lab for the "Java Advanced" course @ Software University.

• Project Architecture;
• Code Refactoring;
• Enumerations;
• Static Keyword;
• Java Packages.
