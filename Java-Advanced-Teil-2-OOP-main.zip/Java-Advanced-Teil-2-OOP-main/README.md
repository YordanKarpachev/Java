# Software University - Java-Advanced-Teil-2-OOP


Themen:

01.Resources;
02.Course Introduction;
03.Working with Abstraction;
04.Exercise: Working with Abstraction;
05.Encapsulation;
06.Exercise: Encapsulation;
07.Inheritance;
08.Exercise: Inheritance;
09.Interfaces and Abstraction;
10.Exercise: Interfaces and Abstraction;
11.Polymorphism;
12.Exercise: Polymorphism;
13.SOLID;
14.Exercise: SOLID;
15.Reflection and Annotation;
16.Exercise: Reflection and Annotation;
17.Exceptions and Error Handling;
18.Debugging Techniques;
19.Unit Testing;
20.Exercise: Unit Testing;
21.Test Driven Development;
22.Exercise: Test Driven Development;
23.Design Patterns;
24.Exercise: Design Patterns;
25.Exam Preparation;
26.Exam Preparation;
27.Exam Preparation;
28.Regular Exam;
29.Retake Exam;
