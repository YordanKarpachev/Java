
public class A810Regen2 {
    public static void main(String[] args) {
        int[][] wetter = new int[3][5];
        int gesamtNiederschlagsmenge = 0;
        //Region Nord:  //Montag 3  //Dienstag 7 //Mittwoch 0 //Donnerstag 10 //Freitag 16

        wetter[0][0] = 3;
        wetter[0][1] = 7;
        // wetter[0][2] = 0;
        wetter[0][3] = 10;
        wetter[0][4] = 16;

        // Region Mitte: Montag 5 Dienstag 1 Mittwoch 0 Donnerstag 0 Freitag 6
        wetter[1][0] = 5;
        wetter[1][1] = 1;


        wetter[1][4] = 6;

        // Region Süd: Montag 4 Dienstag 18 Mittwoch 3 Donnerstag 0 Freitag 2
        wetter[2][0] = 4;
        wetter[2][1] = 18;
        wetter[2][2] = 3;

        wetter[2][4] = 2;

        for (int i = 0; i < 5; i++) {
            gesamtNiederschlagsmenge +=wetter[0][i];
            System.out.print(wetter[0][i] + " ");

        }
        System.out.println();
        for (int i = 0; i < 5; i++) {
            gesamtNiederschlagsmenge +=wetter[1][i];
            System.out.print(wetter[1][i] + " ");

        }
        System.out.println();
        for (int i = 0; i < 5; i++) {
            gesamtNiederschlagsmenge +=wetter[2][i];
            System.out.print(wetter[2][i] + " ");

        }
        System.out.println();
        System.out.println("die Gesamt-Niederschlagsmenge: " + gesamtNiederschlagsmenge);
    }
}
