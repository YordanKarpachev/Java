
public class A81GehaltsBuchhaltung {
    public static void main(String[] args) {
        int[] gehalt = new int[]{1200, 4000, 1000, 700, 1100};

        for (int i = 0; i < gehalt.length; i++) {
            System.out.println(gehalt[i]);
        }
    }
}
