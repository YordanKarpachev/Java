
public class A83GehaltsBuchhaltung3 {
    public static void main(String[] args) {
        int[] gehalt = new int[]{1200, 4000, 1000, 700, 1100};

        int duchschnitt = 0;
        int minGehalt = Integer.MAX_VALUE;
        for (int i = 0; i <= gehalt.length - 1 ; i++) {
            System.out.println(gehalt[i]);
            duchschnitt += gehalt[i];
            if (minGehalt > gehalt[i])
            {
                minGehalt = gehalt[i];
            }
        }
        duchschnitt /= gehalt.length ;
        System.out.println("das durchschnittliche Gehalt: " +duchschnitt);
        System.out.println("das kleinste Gehalt: " + minGehalt );
    }
}
