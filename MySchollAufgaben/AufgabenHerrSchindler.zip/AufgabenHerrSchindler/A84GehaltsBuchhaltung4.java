
import java.util.Arrays;
import java.util.Scanner;

public class A84GehaltsBuchhaltung4 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int[] gehalt = Arrays.stream(scanner.nextLine().split(", "))
                .mapToInt((index -> Integer.parseInt(index))).toArray();

        // beim input "1200, 4000, 1000, 700, 1100" wie genau auf der Aufgabe steht
        // oder genau gesagt bei zahlen getrennt duch koma und leere zeile ( siehe regex beim split)

        int duchschnitt = 0;
        int minGehalt = Integer.MAX_VALUE;
        for (int i = 0; i <= gehalt.length - 1 ; i++) {
            System.out.println(gehalt[i]);
            duchschnitt += gehalt[i];
            if (minGehalt > gehalt[i])
            {
                minGehalt = gehalt[i];
            }
        }
        duchschnitt /= gehalt.length ;
        System.out.println("das durchschnittliche Gehalt: " +duchschnitt);
        System.out.println("das kleinste Gehalt: " + minGehalt );
    }
}
