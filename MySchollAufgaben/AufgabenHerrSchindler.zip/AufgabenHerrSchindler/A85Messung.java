
import java.util.Scanner;

public class A85Messung {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String input = scanner.nextLine();

        int[] zahlen = new int[10];
        int index = 0;

        while (!input.equals("")){
            zahlen[index] = Integer.parseInt(input);
            index++;

            input = scanner.nextLine();

        }

        double sum = 0;

        for (int i = 0; i < index; i++) {

            sum += zahlen[i];
        }

        sum /= index;
        System.out.println("Durchschnittswert: "+ sum);
    }
}
