

import java.util.Scanner;

public class A86Messung2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();

        int[] zahlen = new int[10];
        int index = 0;

        while (!input.equals("")){
            zahlen[index] = Integer.parseInt(input);
            index++;

            input = scanner.nextLine();

        }

        double sum = 0;
        int kleinsteWert = Integer.MAX_VALUE;
        int grossteWert = Integer.MIN_VALUE;

        for (int i = 0; i < index; i++) {

            sum += zahlen[i];
            if (kleinsteWert > zahlen[i]){
                kleinsteWert = zahlen[i];
            }
            if (grossteWert < zahlen[i]){
                grossteWert = zahlen[i];
            }
        }

        sum /= index;
        System.out.println("Durchschnittswert: "+sum);
        System.out.println("der kleinsten Wert: " + kleinsteWert);
         System.out.println("der größten Wert: " + grossteWert);
    }
}
