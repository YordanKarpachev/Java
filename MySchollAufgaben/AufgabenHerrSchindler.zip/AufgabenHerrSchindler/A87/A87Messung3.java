

import java.util.Scanner;

import static com.company.A87.Statistik.*;

public class A87Messung3 {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();

        int[] zahlen = new int[10];
        int index = 0;

        while (!input.equals("")) {
            zahlen[index] = Integer.parseInt(input);
            index++;

            input = scanner.nextLine();

        }

        int[] messreihe = new int[index];

        for (int i = 0; i < index; i++) {
            messreihe[i] = zahlen[i];
        }

        double sum =  durchschnitt( messreihe);
        int min = minimum (messreihe);
        int max = maximum (messreihe);



        System.out.println("Durchschnittswert: " + sum);
        System.out.println("der kleinsten Wert: " + min);
        System.out.println("der größten Wert: " + max);
    }




}

