

public class Statistik {
    public static double durchschnitt(int[] messreihe) {
        double sum = 0;
        for (int i = 0; i < messreihe.length ; i++) {

            sum += messreihe[i];

        }

        sum /= messreihe.length ;
        return sum;

    }

    public static int minimum(int[] messreihe) {

        int kleinsteWert = Integer.MAX_VALUE;
        for (int i = 0; i <= messreihe.length - 1; i++) {


            if (kleinsteWert > messreihe[i]) {
                kleinsteWert = messreihe[i];
            }

        }
        return kleinsteWert;
    }


    public static int maximum(int[] messreihe) {
        int grossteWert = Integer.MIN_VALUE;

        for (int i = 0; i <= messreihe.length - 1; i++) {


            if (grossteWert < messreihe[i]) {
                grossteWert = messreihe[i];
            }
        }
        return grossteWert;
    }


}
