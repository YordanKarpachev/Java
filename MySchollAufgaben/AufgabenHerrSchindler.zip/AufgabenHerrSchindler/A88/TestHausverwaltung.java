
public class TestHausverwaltung {
    public static void main(String[] args) {
        Wohnung [] wohnungs = new Wohnung[10];
        int mietnummer = 22211;
        //gesamtmiete(mietnummer);

        //Aufgabe nicht klar definiert !?
        //wie viele miete soll eine wohnung kosten?
        //wie viele wohnungen pro mietnummer !?
        //die information soll in den console eingegeben !?
        //die program soll berechnen und am ende 2 mal True ausgeben, True für was !?
        //das Program muss immer lauffähig bleiben !?
        //was soll nei konstruktor eingebaut werden ? int mietpreis ? int[] wohnungen ?
    }
}
