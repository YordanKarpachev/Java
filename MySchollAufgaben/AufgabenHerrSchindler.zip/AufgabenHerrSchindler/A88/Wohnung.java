

public class Wohnung {
    int mietnummer;
    int wohnungPrice;
    int garage;
    int[] wohnungen;
}
